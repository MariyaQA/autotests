package OrderCreation;

import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class CreateBtnTest {
    private WebDriver driver;
    private AmarkiSite website;

    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath );
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        website = new AmarkiSite(driver);

        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();


    }
    @Test
    public void makeAnOrder() throws InterruptedException {
        System.out.println("Test1:Scroll to Promotions block");
        website.testSteps().scrollToPromotions();

        System.out.println("Test2:Open order container");
        website.testSteps().chooseFirstTemplate();
        website.testSteps().createBtnClick();

        System.out.println("Test3:Enter job Name ");
        website.testSteps().enterJobName();

        System.out.println("Test4:Select paper coating");
        website.testSteps().paperDropdownSelection();

        System.out.println("Test5:Click on Continue button");
        website.testSteps().clickOnContinueBtn();

        Thread.sleep(1000);
        System.out.println("Test6:Check that user transfer to Template Designer");
        website.checkerClass().checkDesignRunning();


    }
    @After
    public void tearDown(){
        if (driver != null);
            driver.quit();
   }


}
