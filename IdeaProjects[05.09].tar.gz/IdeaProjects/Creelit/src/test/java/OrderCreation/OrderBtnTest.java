package OrderCreation;

import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class OrderBtnTest {
    private WebDriver driver;
    private AmarkiSite website;

    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath);
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        website = new AmarkiSite(driver);

        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();

    }
    @Test
    public void getAnOrder() throws InterruptedException {
        website.testSteps().scrollToPromotions();

        System.out.println("Test1:Wait till template appears and click on Create button");
        website.testSteps().chooseFirstTemplate();
        Thread.sleep(1000);
        website.testSteps().clickOnBtn();

        System.out.println("Test2:Filling the title");
        website.testSteps().enterOrderName();


        System.out.println("Test3:Filling quantity");
        website.testSteps().clearField();
        website.testSteps().enterQuantity();

        Thread.sleep(1000);
        System.out.println("Test4:Click on Continue button");
        website.testSteps().continueBtnClick();

        Thread.sleep(1000);
        website.checkerClass().checkCartUrl();


    }
    @After
    public void tearDown(){
        if (driver != null);
            driver.quit();
    }


}
