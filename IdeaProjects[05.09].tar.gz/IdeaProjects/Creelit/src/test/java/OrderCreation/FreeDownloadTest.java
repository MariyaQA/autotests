package OrderCreation;

import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FreeDownloadTest {
    private WebDriver driver;
    private AmarkiSite website;


    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath );
        driver = new ChromeDriver();
        website = new AmarkiSite(driver);

        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();


    }
    @Test
    public void freeQuickDownload() throws InterruptedException {
        System.out.println("Hover on Create button and make shure that menu is present");
        website.testSteps().hoverOnCreateBtn();

        System.out.println("Test1:Hover on Agent Marketing category");
        website.testSteps().chooseAgentMarkCat();
        Thread.sleep(2000);

        System.out.println("Test2:Hover on Slogans / Phrases and click");
        website.testSteps().chooseSlogansCat();

        System.out.println("Test3:Tap on Free Download button and load the file automatically");
        website.testSteps().clickFreeDownloadBtn();



    }
    @After
    public void tearDown(){
        if (driver != null);
            driver.quit();
    }


}
