package AmarkiHome;


import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class SliderTest {
    private WebDriver driver;
    private AmarkiSite website;


    @Before
    public void setUp() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath);
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
        website = new AmarkiSite(driver);

        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();

   }
    @Test
    public void testingHomePageSlider() throws InterruptedException {
        System.out.println("Test1: Check that Arrow is clickable and EDDM picture is displayed");
        website.checkerClass().checkingCorrectImg();

        System.out.println("Test2: Check that Arrow is clickable and Add Some Shine picture is displayed");
        website.testSteps().arrowLeftClick();
        website.checkerClass().checkCorrectImg();

        System.out.println("Test3: Check that Arrow is clickable and New BusinessCards picture is displayed");
        website.testSteps().arrowLeftClick();
        website.checkerClass().imgChecking();

    }


     @After
    public void tearDown(){
         if (driver != null);
             driver.quit();
  }

}




