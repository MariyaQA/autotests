package AmarkiHome;

import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;



public class TrendItemsCountTest {
    private WebDriver driver;
    private AmarkiSite website;


    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath);
        driver = new ChromeDriver();
        website = new AmarkiSite(driver);
        WebDriverWait wait = new WebDriverWait(driver, 30);

        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();


    }
    @Test
    public void buttonsAndItemsChecking() throws InterruptedException {
        System.out.println("Test1:Check that buttons are clickable");
        website.testSteps().sizeBigDimension();
        website.testSteps().scrollToTrendItems();

        Thread.sleep(1000);
        System.out.println("Click right button and check that 6 elements is present");
        website.testSteps().rightBtnClick();
        website.checkerClass().checkElementsPresence();

        Thread.sleep(1000);
        System.out.println("Click left button and check that 6 elements is present");
        website.testSteps().leftBtnClick();
        website.checkerClass().checkElementsPresence();

    }

    @After
    public void tearDown(){
        if (driver != null);
            driver.quit();

    }


}
