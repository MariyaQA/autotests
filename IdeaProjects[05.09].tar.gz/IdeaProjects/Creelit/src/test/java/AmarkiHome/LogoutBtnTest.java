package AmarkiHome;

import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LogoutBtnTest {
    private WebDriver driver;
    private AmarkiSite website;

    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath);
        driver = new ChromeDriver();
        website = new AmarkiSite(driver);

        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();

    }

    @Test
    public void logoutFromAccount() {
        System.out.println("Test1: Check that logout button is clickable and working properly");
        website.testSteps().clickOnToggleBtn();
        website.testSteps().clickOnLogoutBtn();

    }
    @After
    public void tearDown(){
        if (driver != null);
            driver.quit();
    }

}
