package AmarkiHome;

import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class DropdownCreateTest {
    private WebDriver driver;
    private AmarkiSite website;


    @Before
    public void setUp() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath);
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        website = new AmarkiSite(driver);


        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();
    }

    @Test
    public void dropdownMenu() {
        System.out.println("Test1: Check that Create dropdown menu is displayed by hover on button");
        website.testSteps().hoverOnCreateBtn();
        website.checkerClass().checkMenuIsPresent();
    }

    @Test
    public void clickOnBtn() {
        System.out.println("Test2: Check that by clicking on Create button user stays at the Home Page");
        website.testSteps().clickOnCreateBtn();
        website.checkerClass().checkMenuIsPresent();
        website.checkerClass().checkHomePage();
        }

        @After
        public void tearDown () {
            if (driver != null)
                driver.quit();
        }


}

