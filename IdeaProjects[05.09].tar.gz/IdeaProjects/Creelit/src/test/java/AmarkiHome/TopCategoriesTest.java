package AmarkiHome;

import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TopCategoriesTest {
    private WebDriver driver;
    private AmarkiSite website;

           @Before
           public void setUp(){
               System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath);
               driver = new ChromeDriver();
               website = new AmarkiSite(driver);

               website.mainSteps().openSite();
               website.mainSteps().tapOnSignUpBtn();
               website.mainSteps().selectSignInTab();
               website.mainSteps().clearLoginField();
               website.mainSteps().typeLogin();
               website.mainSteps().clearPasswordField();
               website.mainSteps().typePassword();
               website.mainSteps().clickGo();

           }
           @Test
           public void checkingUrl() throws InterruptedException {
               System.out.println("Test:Check that all urls is correct");
               driver.manage().window().setSize(new Dimension(1920, 1080));

               website.testSteps().scrollToTopCat();

               Thread.sleep(1000);

               System.out.println("Open EDDM");
               website.testSteps().openEddmSection();
               website.checkerClass().checkEddmUrl();
               website.testSteps().goBackToHomesmart();

               Thread.sleep(1000);
               website.testSteps().openBusinessSection();
               website.checkerClass().checkCardUrl();
               driver.navigate().back();

               Thread.sleep(1000);
               System.out.println("Open Yard Signs");
               website.testSteps().openYardSignsSection();
               website.checkerClass().checkOpenYardUrl();
               website.testSteps().goBackToHomesmart();

               Thread.sleep(1000);
               System.out.println("Open Lighted Yard Signs");
               website.testSteps().openLightedSection();
               website.checkerClass().checkYardUrl();
               website.testSteps().goBackToHomesmart();

               Thread.sleep(1000);
               System.out.println("Open Marketing Flyers");
               website.testSteps().openMarketingSection();
               website.checkerClass().checkMarketUrl();
               website.testSteps().goBackToHomesmart();

               Thread.sleep(1000);
               System.out.println("Open House Signs");
               website.testSteps().openHouseSignsSection();
               website.checkerClass().checkHouseUrl();
               website.testSteps().goBackToHomesmart();

               Thread.sleep(1000);
               System.out.println("Open T-Shirts");
               website.testSteps().openTshirtSection();
               website.checkerClass().checkShirtUrl();
               website.testSteps().goBackToHomesmart();

    }

    @After
    public void tearDown(){
        if (driver != null);
            driver.quit();

    }


}
