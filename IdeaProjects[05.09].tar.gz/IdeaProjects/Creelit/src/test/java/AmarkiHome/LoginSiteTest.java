package AmarkiHome;

import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginSiteTest {
    private WebDriver driver;
    private AmarkiSite website;


    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath);
        driver = new ChromeDriver();
        website = new AmarkiSite(driver);

        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();


    }

    @Test
    public void checkWebsiteUrl() {
        System.out.println("Test1: Check that opened link is correct");
        website.checkerClass().checkHomePage();

    }
    @After
    public void tearDown() {
        if (driver != null)
            driver.quit();

    }

}
