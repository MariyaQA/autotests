package AmarkiHome;

import AmarkiHome.Pages.AmarkiSite;
import AmarkiHome.Pages.MainSteps;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class PromoCreateBtnTest {
    private WebDriver driver;
    private AmarkiSite website;


    @Before
    public void steUp(){
        System.setProperty("webdriver.chrome.driver", MainSteps.Config.chromeDriverPath);
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        website = new AmarkiSite(driver);
        JavascriptExecutor je = (JavascriptExecutor) driver;

        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();

    }
    @Test
    public void checkElementIsPresent() {
        System.out.println("Test1: Element is displayed at Home page");
        website.testSteps().scrollToPromotions();

        System.out.println("Test2: Buttons are workable in current block");
        website.testSteps().createBtnClick();

    }
    @After
    public void tearDown(){
        if (driver != null);
            driver.quit();
    }



}
