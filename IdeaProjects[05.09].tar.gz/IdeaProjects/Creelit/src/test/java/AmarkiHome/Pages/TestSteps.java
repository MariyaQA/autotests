package AmarkiHome.Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class TestSteps extends AmarkiSite {
    Actions action = new Actions(driver);
    JavascriptExecutor je = (JavascriptExecutor) driver;

    public TestSteps(WebDriver driver) {
        super(driver);

        PageFactory.initElements(driver, this);
    }

//Slider Test
    public void arrowLeftClick(){
        arrowLeft.click();
    }

    @FindBy (css = ".fa.fa-angle-left")
    private WebElement arrowLeft;


//Dropdown Cart Test
    public void clickOnViewCartBtn(){
        viewCartBtn.click();
    }
    @FindBy (css = ".btn.btn-danger.btn-block")
    private WebElement viewCartBtn;

    public void clickViewCartBtn(){
        WebElement dropdown = driver.findElement(By.cssSelector(".header-cart.dropdown-toggle"));
        action = new Actions(driver);
        action.moveToElement(dropdown).click().perform();
    }

    public void hoverOnCart(){
        WebElement dropdown = driver.findElement(By.cssSelector(".header-cart.dropdown-toggle"));
        action = new Actions(driver);
        action.moveToElement(dropdown).click().perform();
    }


//Dropdown Create Test
    public void hoverOnCreateBtn(){
        WebElement dropdown = driver.findElement(By.cssSelector(".dropdown-full-width.dropdown-hover>a"));
        action = new Actions(driver);
        action.moveToElement(dropdown).click().perform();
    }

    public void clickOnCreateBtn(){
        checkBtnClick.click();
    }
    @FindBy (xpath = ".//*[@id='top-navbar']/ul/li[2]/a")
    private WebElement checkBtnClick;

//Logo Btn Test
    public void clickOnOrderTrBtn(){
        orderBtnClick.click();
    }
    @FindBy (linkText = "Order Tracker")
            private WebElement orderBtnClick;

    public void clickOnLogoBtn(){
        logoBtnClick.click();
    }
    @FindBy (className = "fa-home")
    private WebElement logoBtnClick;

    public void clickOnHomeBtn(){
        homeBtnClick.click();
    }
    @FindBy (css = ".nav.navbar-nav>li>a")
    private WebElement homeBtnClick;

//Logout Button Test
    public void clickOnToggleBtn(){
        toggleBtnClick.click();
    }
    @FindBy (css = ".caret")
    private WebElement toggleBtnClick;

    public void clickOnLogoutBtn(){
        logoutBtnClick.click();
    }
    @FindBy (css = "a[href*='Logout']")
    private WebElement logoutBtnClick;

//Open Manage Test
    public void clickOnManageBtn(){
        manageBtnClick.click();
    }
    @FindBy (css = "a[href*='manage.php']")
    private WebElement manageBtnClick;

//Open MyAcc Test
    public void clickOnMyAccBtn(){
        myAccBtnClick.click();
    }
    @FindBy (css = "a[href*='user.php'")
    private WebElement myAccBtnClick;

//Open Order History Test
    public void clickOnHistoryBtn(){
        orderBtnClick.click();
    }
    @FindBy (css = "a[href*='order.php']")
    private WebElement historyBtnClick;
//Promo Create Btn Test
    public void scrollToPromotions(){
        WebElement element = driver.findElement(By.cssSelector("#promotions"));
        ((JavascriptExecutor)
                driver).executeScript("arguments[0].scrollIntoView();",element);
    }
    public void createBtnClick(){
        clickCreateBtn.click();
    }
    @FindBy (css = "div#promotions a:nth-of-type(1)")
    private WebElement clickCreateBtn;
//ShowAllBtnTest
    public void scrollToShowAllBtn(){
        ((JavascriptExecutor) driver).executeScript("scroll(0,900)");
        driver.findElement(By.cssSelector(".section-title.clearfix"));
    }
    public void clickOnShowAllBtn(){
        driver.findElement(By.xpath(".//*[@id='mobile-list']//h4/a")).click();
    }
    @FindBy (xpath = ".//*[@id='mobile-list']//h4/a")
    private WebElement showAllBtnClick;

//Social Top Bar Test
    public void goBackToHomesmart(){
        driver.navigate().back();
    }

    public void clickOnFbIcon(){
        socialFb.click();
    }
    @FindBy (css = "a[href*='facebook.com/homesmart']")
    private WebElement socialFb;

    public void clickOnTwIcon(){
        socialTw.click();
    }
    @FindBy (css = "a[href*='twitter.com/HomeSmartIntl']")
    private WebElement socialTw;

    public void clickOnGplusIcon(){
        socialGplus.click();
    }
    @FindBy (css = "a[href*='plus.google.com/+Homesmartinternational']")
    private WebElement socialGplus;

    public void clickOnLnIcon(){
        socialLn.click();
    }
    @FindBy (css = "a[href*='linkedin.com/company-beta/1051118/']")
    private WebElement socialLn;

    public void clickOnYtubeIcon(){
        socialYtube.click();
    }
    @FindBy (css = "a[href*='youtube.com/user/homesmart']")
            private WebElement socialYtube;
//Top Categories Test
    public void scrollToTopCat(){
        ((JavascriptExecutor) driver).executeScript("scroll(0,1000)");
    }

    public void openEddmSection(){
        openEddm.click();
    }
    @FindBy (xpath = ".//*[@id='mobile-list']//ul/li[2]/a")
    private WebElement openEddm;

    public void openBusinessSection(){
        openBC.click();
    }
    @FindBy (xpath = ".//*[@id='mobile-list']//ul/li[3]/a")
    private WebElement openBC;

    public void openYardSignsSection(){
        openYS.click();
    }
    @FindBy (xpath = ".//*[@id='mobile-list']//ul/li[4]/a")
    private WebElement openYS;

    public void openLightedSection(){
        openLighted.click();
    }
    @FindBy (xpath = ".//*[@id='mobile-list']//ul/li[5]/a")
    private WebElement openLighted;

    public void openMarketingSection(){
        openMarketing.click();
    }
    @FindBy (xpath = ".//*[@id='mobile-list']//ul/li[6]/a")
    private WebElement openMarketing;

    public void openHouseSignsSection(){
        openHouseSigns.click();
    }
    @FindBy (xpath = ".//*[@id='mobile-list']//ul/li[7]/a")
    private WebElement openHouseSigns;

    public void openTshirtSection(){
        openTshirts.click();
    }
    @FindBy (xpath = ".//*[@id='mobile-list']//ul/li[8]/a")
    private WebElement openTshirts;
//Trend Create test
    public void scrollToTrendItems(){
        ((JavascriptExecutor) driver).executeScript("scroll(0,900)");
    }
    public void clickOnTemplateImg(){
        driver.findElement(By.cssSelector(".col-md-2.col-sm-4.col-xs-12.cloneditem-3"))
                .findElement(By.cssSelector(".item-image.cit-template-img.previewImage>img")).click();
    }
    public void clickOnCreateButton(){
        createInsideTemplate.click();
    }
    @FindBy (css = "#createTemplate")
    private WebElement createInsideTemplate;

//Dimensions
    public void sizeBigDimension(){
        driver.manage().window().setSize(new Dimension(1920, 1080));
    }
    public void sizeMidDimension(){
        driver.manage().window().setSize(new Dimension(868, 1024));
    }
    public void sizeSmallDimension(){
        driver.manage().window().setSize(new Dimension(360, 640));
    }

//Trending Items Count Test
    public void rightBtnClick(){
        rightBtnPull.click();
    }
    @FindBy (xpath = ".//*[@id='trending-items']/div/h4/a[2]")
    private WebElement rightBtnPull;

    public void leftBtnClick(){
        leftBtnPull.click();
    }
    @FindBy (xpath = ".//*[@id='trending-items']/div/h4/a[1]")
    private WebElement leftBtnPull;
//Zoom In Out Test
    public void clickOnTemplatePImg(){
        driver.findElement(By.cssSelector(".col-md-2.col-sm-4.col-xs-12.cloneditem-3"))
                .findElement(By.cssSelector(".item-image.cit-template-img.previewImage>img")).click();
    }
    public void clickOnCloseBtn(){
        closeBtnClick.click();
    }
    @FindBy (xpath = ".//*[@id='previewImageModal']//button")
    private WebElement closeBtnClick;
//Create Button Test
    public void chooseFirstTemplate(){
        firstTemplate.isDisplayed();
    }
    @FindBy (css = ".promotion-caption.promotion-caption-inverse")
    private WebElement firstTemplate;

    public void enterJobName(){
        jobNameEnter.sendKeys("AutoTestCreate");
    }
    @FindBy (id = "input-title")
    private WebElement jobNameEnter;

    public void paperDropdownSelection(){
        Select droplist = new Select(driver.findElement(By.id("select-coating")));
        droplist.selectByVisibleText("UV 1 Side Front");
    }
    public void clickOnContinueBtn(){
        continueBtn.click();
    }
    @FindBy (xpath = "//button[contains(.,'Continue')]")
    private WebElement continueBtn;

//Create Order to Cart test
    public void clickOnNextBtn(){
        nextBtn.click();
    }
    @FindBy (id = "nextButton")
    private WebElement nextBtn;

    public void waitAndClickOnNextBtn(){
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#nextButton")));
    }
    public void clickSaveToFinish(){
        clickToFinish.click();
    }
    @FindBy (id = "btnSaveFinish")
    private WebElement clickToFinish;

    public void goToCartBtnClick(){
        cartBtn.click();
    }
    @FindBy (id = "goToCart")
    private WebElement cartBtn;

    public void continueShoppingBtnClick(){
        goToShoppingBtn.click();
    }
    @FindBy (id = "goToCreate")
    private WebElement goToShoppingBtn;

//Free download test
    public void chooseAgentMarkCat(){
        WebElement dropdownFirst = driver.findElement(By.xpath(".//*[@id='top-navbar']/ul/li[2]/div/div/div[1]/ul/li[1]/a"));
        action = new Actions(driver);
        action.moveToElement(dropdownFirst).perform();
    }
    public void chooseSlogansCat(){
        WebElement dropdownClick1 = driver.findElement(By.xpath(".//*[@id='top-navbar']/ul/li[2]//div[1]/ul/li[12]/a"));
        action = new Actions(driver);
        action.moveToElement(dropdownClick1).perform();
        dropdownClick1.click();
    }
    public void clickFreeDownloadBtn(){
        freeDownloadBtn.click();
    }
    @FindBy (xpath = ".//*[@id='c_campaign_templatelist']/div/div/div/div[1]/div/div[1]/div[1]/div/div[3]/a")
    private WebElement freeDownloadBtn;
//Order btn test
   public void clickOnBtn(){
       buttonClick.click();
   }
   @FindBy (xpath = ".//*[@id='promotions']//div[3]/div[2]/div[2]/a")
   private WebElement buttonClick;

   public void enterOrderName(){
       orderName.sendKeys("AutoTestOrder");
   }
   @FindBy (id = "input-title")
    private WebElement orderName;

   public void clearField(){
       clearingField.clear();
   }
   @FindBy (css = "#input-quantity")
    private WebElement clearingField;

   public void enterQuantity(){
       quantityEnter.sendKeys("10");
   }
   @FindBy (css = "#input-quantity")
    private WebElement quantityEnter;

   public void continueBtnClick(){
       contBtnClick.click();
   }
   @FindBy (xpath = "//button[contains(.,'Continue')]")
    private WebElement contBtnClick;












}
