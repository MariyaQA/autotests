package AmarkiHome.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MainSteps extends AmarkiSite {


    public MainSteps(WebDriver driver) {
        super(driver);

        PageFactory.initElements(driver, this);
    }
    public static class Config {
        public final static String chromeDriverPath = System.getProperty("user.dir") + "/drivers/chromedriver";
    }

    public static String siteName = "https://amarki.com/";

    @FindBy(css = "a[class*='skin-styledButton']")
    private WebElement signUpBtn;

    @FindBy (xpath = "//li[1]/a")
    private WebElement signInTab;

    @FindBy (name = "user_login")
    private WebElement clearLoginField;

    @FindBy (name = "user_login")
    private WebElement typeLogin;

    @FindBy (name = "user_password")
    private WebElement clearPwrdField;

    @FindBy (name = "user_password")
    private WebElement typePassword;

    @FindBy (name = "go")
    private WebElement enterSignIn;

    @FindBy (css = ".fa.fa-angle-left")
    private WebElement clickOnArrow;

    @FindBy (xpath = ".//*[@id='main-carousel']//div[3]/div[2]")
    private WebElement checkingPic;

    @FindBy (xpath = ".//*[@id='main-carousel']//div[1]/div[1]/img")
    private WebElement checkPic;

    @FindBy (css = ".fa.fa-angle-left")
    private WebElement arrowLeft;

    @FindBy (xpath = ".//*[@id='main-carousel']/div/div[1]/img")
    private WebElement picChechk;


//Main steps from setup
//    public void open(String url) {
//    driver.get(url);
//}
    public void openSite(){
        driver.get("https://amarki.com/");
    }




    public void tapOnSignUpBtn(){
        signUpBtn.click();
        System.out.println("Step1: Tap on SignUp button");
    }
    public void selectSignInTab(){

        signInTab.click();
        System.out.println("Step2: Select Sign In tab");
    }
    public void clearLoginField(){

        clearLoginField.clear();
        System.out.println("Step3: Clear login field");
    }
    public void typeLogin(){

        typeLogin.sendKeys("hsi");
        System.out.println("Step4: Type correct login");
    }
    public void clearPasswordField(){

        clearPwrdField.clear();
        System.out.println("Step5: Clear password field");
    }
    public void typePassword(){

        typePassword.sendKeys("liw09YAZ85");
        System.out.println("Step6: Type correct password");
    }
     public void clickGo(){

        enterSignIn.click();
        System.out.println("Step7: Click on Sign In button");
     }














}
