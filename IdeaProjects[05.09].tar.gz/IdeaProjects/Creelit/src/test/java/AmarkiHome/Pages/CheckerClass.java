package AmarkiHome.Pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckerClass extends AmarkiSite{

    public CheckerClass(WebDriver driver) {
        super(driver);

        PageFactory.initElements(driver, this);
    }


//Slider Test
    public void checkCorrectImg(){
        checkingImg.isDisplayed();
    }
    @FindBy(xpath = ".//*[@id='main-carousel']//div[3]/div[2]")
    private WebElement checkingImg;

    public void checkingCorrectImg(){
        checkImg.isDisplayed();
    }
    @FindBy (xpath = ".//*[@id='main-carousel']//div[1]/div[1]/img")
    private WebElement checkImg;

    public void imgChecking(){
        imgCheck.isDisplayed();
    }
    @FindBy (xpath = ".//*[@id='main-carousel']/div/div[1]/img")
    private WebElement imgCheck;


//Dropdown Cart Test
    public void dropdownCartDisplays(){
    dropdownCart.isDisplayed();
    }
    @FindBy (css = ".header-cart.dropdown-toggle")
    private WebElement dropdownCart;

//Dropdown Create Test
    public void checkMenuIsPresent(){
    menuIsPresent.isDisplayed();
    }
    @FindBy (css = ".dropdown-full-width.dropdown-hover>a")
    private WebElement menuIsPresent;


    public void checkHomePage(){
        Assert.assertTrue(driver.getCurrentUrl().contains("welcome.php"));
    }
    public void checkCartUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("cart.php"));
    }

//Logo Button Test
    public void checkBtnRedirect(){
        Assert.assertTrue(driver.getCurrentUrl().contains("/welcome.php"));
    }

//Open Manage Test
    public void checkManageOpens(){
        Assert.assertTrue(driver.getCurrentUrl().contains("manage.php"));
    }
//Open My Acc Test
    public void checkMyAccOpens(){
        Assert.assertTrue(driver.getCurrentUrl().contains("user.php"));
    }
//Open Order History Test
    public void checkHistoryOpens(){
        Assert.assertTrue(driver.getCurrentUrl().contains("order.php"));
    }
//Show All Btn Test
    public void checkCategoriesUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("GetCategories&category"));
    }
//Social Top Bar Test
    public void checkCorrectFbUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("facebook.com/homesmart"));
    }
    public void checkCorrectTwUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("twitter.com/HomeSmartIntl"));
    }
    public void checkCorrectGplusUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("plus.google.com/+Homesmartinternational"));
    }
    public void checkCorrectYtubeUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("user/homesmart"));
    }
//Top Categories test
    public void checkEddmUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("category=7"));
    }
    public void checkCardUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("category=2"));
    }
    public void checkYardUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("category=10"));
    }
    public void checkOpenYardUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("category=13"));
    }

    public void checkMarketUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("category=6"));
    }
    public void checkHouseUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("category=31"));
    }
    public void checkShirtUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("category=44"));
    }
//Trend Create Test
    public void checkWindowAppear(){
        paramPopup.isDisplayed();
    }
    @FindBy (xpath = ".//*[@id='modal-spec-attributes']//div[2]")
    private WebElement paramPopup;

//Trend Items Count Test
    public void checkElementsPresence(){
        Assert.assertTrue(driver.findElement(By.xpath(".//*[@id='itemslider']/div/div[1]"))
                .findElements(By.cssSelector(".col-md-2.col-sm-4.col-xs-12"))
                .size() == 6);
    }
//Create Btn Test
    public void checkDesignRunning(){
        Assert.assertTrue(driver.getCurrentUrl().contains("RunEditor"));
    }

//Create Order To Cart test
    public void checkCreateCatUrl(){
        Assert.assertTrue(driver.getCurrentUrl().contains("campaign.php"));
    }





}
