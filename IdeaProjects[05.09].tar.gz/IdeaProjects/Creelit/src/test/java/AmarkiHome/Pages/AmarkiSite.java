package AmarkiHome.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class AmarkiSite {
    public final WebDriver driver;

    WebDriverWait wait;
    Actions action;

    public AmarkiSite (WebDriver driver){
        this.driver = driver;
        wait = new WebDriverWait(driver, 50);
        driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
        action = new Actions(driver);

    }

    public MainSteps mainSteps(){return new MainSteps(driver); }

    public TestSteps testSteps(){return new TestSteps(driver); }

    public CheckerClass checkerClass(){return new CheckerClass(driver);}


}
