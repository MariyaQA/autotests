package AmarkiHome;

import AmarkiHome.Pages.AmarkiSite;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class SocialTopBarTest {
    private WebDriver driver;
    private AmarkiSite website;

    @Before
    public void setUp() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "/home/adminubuntu/chromedriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        website = new AmarkiSite(driver);

        website.mainSteps().openSite();
        website.mainSteps().tapOnSignUpBtn();
        website.mainSteps().selectSignInTab();
        website.mainSteps().clearLoginField();
        website.mainSteps().typeLogin();
        website.mainSteps().clearPasswordField();
        website.mainSteps().typePassword();
        website.mainSteps().clickGo();


    }

    @Test
    public void checkingSocials() throws InterruptedException {

        Thread.sleep(1000);
        System.out.println("Test1: Check that FB button is clickable and leeds to HomeSmart community in FB");
        website.testSteps().clickOnFbIcon();
        website.checkerClass().checkCorrectFbUrl();
        website.testSteps().goBackToHomesmart();

        Thread.sleep(1000);
        System.out.println("Test2: Check that TW button is clickable and leeds to HomeSmart community in TW");
        website.testSteps().clickOnTwIcon();
        website.checkerClass().checkCorrectTwUrl();
        website.testSteps().goBackToHomesmart();

        Thread.sleep(1000);
        System.out.println("Test3: Check that Google+ button is clickable and leeds to HomeSmart community in Google+");
        website.testSteps().clickOnGplusIcon();
        website.checkerClass().checkCorrectGplusUrl();
        website.testSteps().goBackToHomesmart();

        Thread.sleep(1000);
        System.out.println("Test4: Check that LinkedIn button is clickable and leeds to HomeSmart community in LinkedIn");
        website.testSteps().clickOnLnIcon();
        website.testSteps().goBackToHomesmart();

        Thread.sleep(2000);
        System.out.println("Test5: Check that YouTube button is clickable and leeds to HomeSmart community in YouTube");
        website.testSteps().clickOnYtubeIcon();
        website.checkerClass().checkCorrectYtubeUrl();
        website.testSteps().goBackToHomesmart();


    }
    @After
    public void tearDown() {
        if (driver != null)
            driver.quit();

    }


}