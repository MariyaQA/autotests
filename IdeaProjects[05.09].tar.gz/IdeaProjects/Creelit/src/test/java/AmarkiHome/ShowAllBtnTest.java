package AmarkiHome;

import AmarkiHome.Pages.AmarkiSite;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class ShowAllBtnTest {
    private WebDriver driver;
    private AmarkiSite website;

        @Before
        public void setUp() {
            System.setProperty("webdriver.chrome.driver", "/home/adminubuntu/chromedriver");
            driver = new ChromeDriver();
            driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
            website = new AmarkiSite(driver);

            website.mainSteps().openSite();
            website.mainSteps().tapOnSignUpBtn();
            website.mainSteps().selectSignInTab();
            website.mainSteps().clearLoginField();
            website.mainSteps().typeLogin();
            website.mainSteps().clearPasswordField();
            website.mainSteps().typePassword();
            website.mainSteps().clickGo();

        }
        @Test
         public void clickingShowAllBtn() {
            System.out.println("Test1:Check that button is clickable");
            driver.manage().window().setSize(new Dimension(1920, 1080));
            website.testSteps().scrollToShowAllBtn();
            website.testSteps().clickOnShowAllBtn();

            System.out.println("Test2:Check that correct url was opened");
            website.checkerClass().checkCategoriesUrl();

        }
        @After
         public void tearDown() {
            if (driver != null);
                driver.quit();
        }



}